package com.example.tiendadecampeones.models;

public class SalesResponse {
    private double total_ventas;

    public double getTotalVentas() {
        return total_ventas;
    }

    public void setTotalVentas(double total_ventas) {
        this.total_ventas = total_ventas;
    }
}