# Acerca de APK
- En esta carpeta (/apk) se encuentra el APK construido a partir del código de este proyecto desarrollado.